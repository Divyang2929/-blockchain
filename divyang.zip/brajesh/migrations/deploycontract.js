var Abhay = artifacts.require("./bk.sol");

module.exports = function(deployer) {
  deployer.deploy(Abhay);
};